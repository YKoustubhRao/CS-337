import json
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
import torch
import joblib
from torch.autograd import Variable
from sklearn import svm
from sklearn import metrics

train_fd = open("./trainingAndTest/training.json")
data_lines = train_fd.readlines()
N = int(data_lines[0])
identiti = torch.eye(8)

data = torch.zeros((N,9))
out = torch.zeros(N)
subject_dict = {"Physics":0, "Chemistry":1, "English":2, "Biology":3, "PhysicalEducation":4,
"Accountancy":5, "BusinessStudies":6, "ComputerScience":7, "Economics":8}

for l in range(N):
    data_dict = json.loads(data_lines[l+1])
    for key in data_dict:
        if key == "Mathematics":
            out[l] = data_dict[key]-1
        elif key != "serial":
            data[l][subject_dict[key]] = data_dict[key]

out_hot = F.one_hot(out.to(torch.int64), num_classes=8)


class TheModelClass(nn.Module):
    def __init__(self):
        super(TheModelClass, self).__init__()
        self.l1 = nn.Linear(9, 64)
        self.l2 = nn.Linear(64, 512)
        self.l4 = nn.Linear(512, 64)
        self.l5 = nn.Linear(64, 8)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.l1(x)
        x = self.relu(x)
        x = self.l2(x)
        x = self.relu(x)
        # x = self.l2(x)
        # x = self.relu(x)
        x = self.l4(x)
        x = self.relu(x)
        x = self.l5(x)
        return x

model = TheModelClass()
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
epochs = 100
model.zero_grad()

for epo in range(epochs):
    model.train()
    for l in range(N//1000):
        # l*1000:(l+1)*1000
        y_pred = model(data[l*1000:(l+1)*1000].float())
        cost = criterion(y_pred, out_hot[l*1000:(l+1)*1000].float())
        optimizer.zero_grad()
        cost.backward()
        optimizer.step()
    acc = 0
    for l in range(N):
        y_pred = torch.argmax(model(data[l].float()))
        x = y_pred.item()
        if x == 0:
            x = 1
        if x == 7:
            x = 6
        if abs(x-out[l]) <= 1:
            acc += 1
    acc = acc/N
    print("epoch", epo, "accuracy", acc)
    



joblib.dump(model, 'test_model.pkl')
saved_model = joblib.load('test_model.pkl')

# print("SVM start")

# clf = svm.SVC(kernel='rbf')
# clf.fit(data, out)
# y_pred = clf.predict(data)
# print("Accuracy:",metrics.accuracy_score(out, y_pred))


################################### Testing The Model ###################################################
input_fd = open("./trainingAndTest/sample-test.in.json", "r")
input_lines = input_fd.readlines()
output_fd = open("./trainingAndTest/sample-test.out.json", "r")
output_lines = output_fd.readlines()

N_test = int(input_lines[0])

acc = 0
for l in range(N_test):
    test = torch.zeros((1,9))
    test_dict = json.loads(input_lines[l+1])
    for key in test_dict:
        if key != "serial":
            test[0][subject_dict[key]] = test_dict[key]

    x = 1+torch.argmax(saved_model(test.float())).item()
    if x == 1:
        x = 2
    if x == 8:
        x = 7
    y = int(output_lines[l].split()[0])
    if abs(x-y) <= 1:
        acc += 1

print("Test Accuracy", acc/N_test)
    # output_fd.write(str(clf.predict(test).item()+1)+"\n")


input_fd.close()
output_fd.close()

################################### Filling Testcases ###################################################

input_fd = open("./Testcases/input/input01.txt", "r")
input_lines = input_fd.readlines()
output_fd = open("./Testcases/output/output01.txt", "w")

N_test = int(input_lines[0])

for l in range(N_test):
    test = torch.zeros((1,9))
    test_dict = json.loads(input_lines[l+1])
    for key in test_dict:
        if key != "serial":
            test[0][subject_dict[key]] = test_dict[key]

    x = 1+torch.argmax(saved_model(test.float())).item()
    if x == 1:
        x = 2
    if x == 8:
        x = 7
    output_fd.write(str(x)+"\n")
    # output_fd.write(str(clf.predict(test).item()+1)+"\n")


input_fd.close()
output_fd.close()
train_fd.close()