import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import SVR

input_fd = open("./Testcases/input/input02.txt", "r")
input_lines = input_fd.readlines()

N = int(input_lines[0])

time_val = np.zeros((N-20,1), dtype=float)
share_val = np.zeros((N-20,1), dtype=float)

missing = []
mis = 0

for l in range(N):
    splito = input_lines[l+1].split()
    time_val[l-mis] = l
    if splito[2][0] == 'M':
        missing.append(l)
        mis += 1
    else:
        share_val[l-mis] = float(splito[2])


regressor = SVR(kernel = 'rbf', C=1000, gamma=0.1)
regressor.fit(time_val, share_val)


output_fd = open("./Testcases/output/output02.txt", "w")

for missi in missing:
    mis = np.zeros((1,1), dtype=float)
    mis[0][0] = missi
    out = regressor.predict(mis)
    out = str(out[0])
    output_fd.write(out+"\n")

input_fd.close()
output_fd.close()

# plt.plot(time_val, share_val)
# plt.show()
