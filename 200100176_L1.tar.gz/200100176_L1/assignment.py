import json
from statistics import variance
from typing import Tuple, List
import numpy as np


def generate_uniform(seed: int, num_samples: int) -> None:
    """
    Generate 'num_samples' number of samples from uniform
    distribution and store it in 'uniform.txt'
    """

    # TODO
    np.random.seed(seed)
    x = np.random.uniform(0.0,1.0,num_samples)
    f = open("uniform.txt", "w")
    
    for rnd in x:
        f.write(str(rnd)+"\n")
    
    f.close()
    # END TODO

    assert len(np.loadtxt("uniform.txt", dtype=float)) == 100
    return None


def inv_transform(file_name: str, distribution: str, **kwargs) -> list:
    """ populate the 'samples' list from the desired distribution """

    samples = []

    # TODO
    poss = ["categorical", "exponential", "cauchy"]
    f = open(file_name, "r")
    Lines = f.readlines()
    array = []
    for l in Lines:
        array = array + [float(l)]
    
    
    if distribution == poss[0]:
        for i in range(100):
            x = array[i]
            val = []
            prob = []
            for key, value in kwargs.items():
                if key == "values":
                    val = value
                if key == "probs":
                    prob = value
                    
            s = 1
            y = 0
            n = len(val)
            for i in range(n):
                s = s - prob[n-1-i]
                if x >= s:
                    y = val[n-1-i]
                    break
            samples.append(y)
            
            
    if distribution == poss[1]:
        for i in range(100):
            x = array[i]
            l = 1.0
            for key, value in kwargs.items():
                if key == "lambda":
                    l = value
                    
            y = (np.log(1/(1-x))/l)
            samples.append(y)
            
            
    if distribution == poss[2]:
        for i in range(100):
            x = array[i]
            p = 1.0
            g = 1.0
            for key, value in kwargs.items():
                if key == "gamma":
                    g = value
                    
                if key == "peak_x":
                    p = value
                    
            y = p + g*(np.tan(np.pi*(x-0.5)))
            samples.append(y)
    
    # END TODO
    assert len(samples) == 100
    return samples


def find_best_distribution(samples: list) -> Tuple[int, int, int]:
    """
    Given the three distributions of three different types, find the distribution
    which is most likely the data is sampled from for each type
    Return a tupple of three indices corresponding to the best distribution
    of each type as mentioned in the problem statement
    """
    indices = (0,0,0)

    # TODO
    for i in range(len(samples)):
        samples[i] = float("{0:.4f}".format(samples[i]))
    
    mu1 = 0.0
    sigma1 = 1.0
    mu2 = 0.0
    sigma2 = 0.5
    mu3 = 1.0
    sigma3 = 1.0

    gaus1 = 0.0
    gaus2 = 0.0
    gaus3 = 0.0
    indices = list(indices)

    for elem in samples:
        temp1 = -0.5*np.power((elem-mu1)/sigma1, 2) - np.log(sigma1)
        gaus1 = float("{0:.4f}".format(gaus1+temp1))

        temp2 = -0.5*np.power((elem-mu2)/sigma2, 2) - np.log(sigma2)
        gaus2 = float("{0:.4f}".format(gaus2+temp2))

        temp3 = -0.5*np.power((elem-mu3)/sigma3, 2) - np.log(sigma3)
        gaus3 = float("{0:.4f}".format(gaus3+temp3))
    
    if gaus1>=gaus2 :
        if gaus1>=gaus3 :
            indices[0] = 0
        else :
            indices[0] = 2
    else:
        if gaus2>=gaus3:
            indices[0] = 1
        else :
            indices[0] = 2
    
    ud1 = 1.0
    ud2 = 1.0
    ud3 = 1.0
    for elem in samples:
        if not(elem>=0 and elem<=1) :
            ud1 = 0.0

        if elem>0.0 and elem<=2.0 :
            ud2 = float("{0:.4f}".format(elem*ud2/2.0))
        else:
            ud2 = 0.0

        if elem>-1.0 and elem<=1.0:
            ud3 = float("{0:.4f}".format(elem*ud3/2.0))
        else:
            ud3 = 0.0
    
    if ud1>ud2:
        if ud1>ud3:
            indices[1] = 0
        else:
            indices[1] = 2
    else:
        if ud2<ud3:
            indices[1] = 2
        else:
            indices[1] = 1
    
    ed1 = 0.0
    ed2 = 1.0
    ed3 = 1.0
    lambda1 = 0.5
    lambda2 = 1.0
    lambda3 = 2.0

    sum = 0.0
    for elem in samples:
        sum += elem
    
    ed1 = 100.0*np.log(lambda1) - lambda1*sum
    ed2 = 100.0*np.log(lambda2) - lambda2*sum
    ed3 = 100.0*np.log(lambda3) - lambda3*sum

    if ed1>ed2:
        if ed1>ed3:
            indices[1] = 0
        else:
            indices[1] = 2
    else:
        if ed2<ed3:
            indices[1] = 2
        else:
            indices[1] = 1

    indices = tuple(indices)
    
    # END TODO
    assert len(indices) == 3
    assert all([index >= 0 and index <= 2 for index in indices])
    return indices

def marks_confidence_intervals(samples: list, variance: float, epsilons: list) -> Tuple[float, List[float]]:

    sample_mean = 0
    deltas = [0 for e in epsilons] # List of zeros

    # TODO
    n = len(samples)
    for i in samples:
        sample_mean = sample_mean + i
        
    sample_mean = sample_mean/n

    p = 0
    for e in epsilons:
        y = e*e
        deltas[p] = variance/y
        p = p+1
    
    # END TODO

    assert len(deltas) == len(epsilons)
    return sample_mean, deltas

if __name__ == "__main__":
    seed = 21734

    # question 1
    generate_uniform(seed, 100)

    # question 2
    for distribution in ["categorical", "exponential", "cauchy"]:
        file_name = "q2_" + distribution + ".json"
        args = json.load(open(file_name, "r"))
        samples = inv_transform(**args)
        with open("q2_output_" + distribution + ".txt", "w") as f:
            for elem in samples:
                f.write(str(elem) + "\n")

    # question 3
    indices = find_best_distribution(np.loadtxt("q3_samples.csv", dtype=float))
    with open("q3_output.txt", "w") as f:
        f.write("\n".join([str(e) for e in indices]))

    # question 4
    q4_samples = np.loadtxt("q4_samples.csv", dtype=float)
    q4_epsilons = np.loadtxt("q4_epsilons.csv", dtype=float)
    variance = 5

    sample_mean, deltas = marks_confidence_intervals(q4_samples, variance, q4_epsilons)

    with open("q4_output.txt", "w") as f:
        f.write("\n".join([str(e) for e in [sample_mean, *deltas]]))
