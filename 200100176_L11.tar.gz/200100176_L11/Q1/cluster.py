import numpy as np
from utils import *
from sklearn.cluster import KMeans
from matplotlib import pyplot as plt


k = 5

data2d = load_points_from_json("points_2D.json")
a = data2d[:,0]
b = data2d[:,1]

X = np.zeros((data2d.shape[0], 3))
X[:,0] = a
X[:,1] = b
X[:,2] = np.multiply(a,a) + np.multiply(b,b)

kmeans = KMeans(n_clusters=k, random_state=0).fit(X)
store_labels_to_json(k, kmeans.labels_, "labels.json")


plt.scatter(a, b, c=kmeans.labels_)
plt.show()

