import numpy as np
from utils import *

data = load_points_from_json("points_4D.json")
U, V, Vt = np.linalg.svd(data)
w2 = Vt.T[:, :2]
data2d = data.dot(w2)
a = data2d[:,0]
b = data2d[:,1]
a = a - np.mean(a)
a = a*2
b = b - np.mean(b)
data2d[:,0] = a
data2d[:,1] = b

store_points_to_json(data2d, "points_2D.json")


