import numpy as np
import torch
from utils import visualize, store_labels
import pandas as pd

np.random.seed(128)

def initialize_random_centroids(K, num_features, num_examples, X):
    centroids = np.zeros((K, num_features)) # row , column full with zero 
    for k in range(K): # iterations of 
        centroid = X[np.random.choice(range(num_examples))] # random centroids
        centroids[k] = centroid
    return centroids # return random centroids
    
    # create cluster Function
def create_cluster(K, X, centroids):
    clusters = [[] for _ in range(K)]
    for point_idx, point in enumerate(X):
        closest_centroid = np.argmin(
            np.sqrt(np.sum((point-centroids)**2, axis=1))
        ) # closest centroid using euler distance equation(calculate distance of every point from centroid)
        clusters[closest_centroid].append(point_idx)
    return clusters 

def calculate_new_centroids(K, num_features, cluster, X):
    centroids = np.zeros((K, num_features)) # row , column full with zero
    for idx, cluster in enumerate(cluster):
        new_centroid = np.mean(X[cluster], axis=0) # find the value for new centroids
        centroids[idx] = new_centroid
    return centroids

# prediction
def predict_cluster(num_examples, clusters, X):
    y_pred = np.zeros(num_examples) # row1 fillup with zero
    for cluster_idx, cluster in enumerate(clusters):
        for sample_idx in cluster:
            y_pred[sample_idx] = cluster_idx
    return y_pred

def get_clusters(X, n_clusters=10):
    '''
    Inputs:
        X: coordinates of the points
        n_clusters: (optional) number of clusters required
    Output:
        labels: The cluster index assigned to each point in X, same length as len(X)
    '''
    #### TODO: ####
    max_iterations = 1000
    num_examples, num_features = X.shape
    K = n_clusters
    centroids = initialize_random_centroids(K, num_features, num_examples, X) # initialize random centroids


    for _ in range(max_iterations):
        clusters = create_cluster(K, X, centroids) # create cluster
        previous_centroids = centroids
        centroids = calculate_new_centroids(K, num_features, clusters, X) # calculate new centroids
        diff = centroids - previous_centroids # calculate difference
        if not diff.any():
            break


    y_pred = predict_cluster(num_examples, clusters, X) # predict function
    return y_pred
    

    ###############    

    # return labels


if __name__ == "__main__":
    data = pd.read_csv("mnist_samples.csv").values
    labels = get_clusters(data)
    store_labels(labels)
    visualize(data, labels, alpha=0.2)
