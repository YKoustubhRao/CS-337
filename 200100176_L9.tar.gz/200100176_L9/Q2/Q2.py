import matplotlib.pyplot as plt
import numpy as np

def kernel_pca(X: np.ndarray, kernel: str) -> np.ndarray:
    '''
    Returns projections of the the points along the top two PCA vectors in the high dimensional space.

        Parameters:
                X      : Dataset array of size (n,2)
                kernel : Kernel type. Can take values from ('poly', 'rbf', 'radial')

        Returns:
                X_pca : Projections of the the points along the top two PCA vectors in the high dimensional space of size (n,2)
    '''

    n, w = X.shape

    if kernel == 'poly':
        ep = 5
        out = np.power(np.dot(X, X.T)+1, ep)

    elif kernel == 'rbf':
        G = 15
        out = np.exp(-G*(np.sum(X**2, axis = 1)[:, None] + np.sum(X**2, axis = 1) - 2*(X@X.T)))

    elif kernel == 'radial':
        x1 = X[:,0]
        x2 = X[:,1]
        p = np.sqrt(x1**2 + x2**2)
        q = np.arctan2(x2, x1)
        A = np.reshape(np.repeat(p,n), (n**2,1))
        B = np.resize(p, (n**2, 1))
        C = np.reshape(np.repeat(q,n), (n**2,1))
        D = np.resize(q, (n**2, 1))
        out = np.reshape((A*B)+(C*D), (n,n))
    else:
        print("Error")

    
    one_mat = np.ones((n,n))/n
    final = out - np.dot(one_mat, out) - np.dot(out, one_mat) + np.dot(one_mat, np.dot(out, one_mat))

    Val, Vec = np.linalg.eigh(final)
    indices = Val.argsort()[::-1]
    evec = Vec[:, indices]
    out = np.matmul(final, np.column_stack([evec[:,i] for i in range(2)]))
    return out

if __name__ == "__main__":
    from sklearn.datasets import make_moons, make_circles
    from sklearn.linear_model import LogisticRegression
  
    X_c, y_c = make_circles(n_samples = 500, noise = 0.02, random_state = 517)
    X_m, y_m = make_moons(n_samples = 500, noise = 0.02, random_state = 517)

    X_c_pca = kernel_pca(X_c, 'radial')
    X_m_pca = kernel_pca(X_m, 'rbf')
    
    plt.figure()
    plt.title("Data")
    plt.subplot(1,2,1)
    plt.scatter(X_c[:, 0], X_c[:, 1], c = y_c)
    plt.subplot(1,2,2)
    plt.scatter(X_m[:, 0], X_m[:, 1], c = y_m)
    plt.show()

    plt.figure()
    plt.title("Kernel PCA")
    plt.subplot(1,2,1)
    plt.scatter(X_c_pca[:, 0], X_c_pca[:, 1], c = y_c)
    plt.subplot(1,2,2)
    plt.scatter(X_m_pca[:, 0], X_m_pca[:, 1], c = y_m)
    plt.show()
