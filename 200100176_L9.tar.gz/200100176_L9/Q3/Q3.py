from utils import *
import numpy as np


############ QUESTION 3 ##############
class KR:
    def __init__(self, x,y,b=1):
        self.x = x
        self.y = y
        self.b = b

    def gaussian_kernel(self, z):
        '''
        Implement gaussian kernel
        '''     
        k = (1/(pow(2*np.pi,0.5)))*np.exp(-1*z*z/2)
        return k

    
    def predict(self, x_test):
        '''
        returns predicted_y_test : numpy array of size (x_train, )
        '''
        predicted_y_test = np.zeros(x_test.shape[0])
        N = self.x.shape[0]
        o=0
        for i in x_test:
            # f1 = np.full(self.x.shape, i)
            summ = 0
            s = np.zeros(N)
            for j in self.x:
                summ += self.gaussian_kernel(j-i)

            for j in range(self.x.shape[0]):
                s[j] = N*self.gaussian_kernel(self.x[j] - i)/summ

            for j in range(N):
                predicted_y_test[o] += self.y[j]*s[j]

            predicted_y_test[o] = predicted_y_test[o]/N

            o += 1

        return predicted_y_test

	
		
def q3():
	#Kernel Regression
	x_train, x_test, y_train, y_test = get_dataset()
	
	obj = KR(x_train, y_train)
	
	y_predicted = obj.predict(x_test)
	
	print("Loss = " ,find_loss(y_test, y_predicted))
    